module.exports = {
    //configLimit is used to limit number of messages that can be stored for a user
    "configLimit" : "3"
}